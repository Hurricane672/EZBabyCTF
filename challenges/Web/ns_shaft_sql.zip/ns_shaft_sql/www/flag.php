<?php

$flag = "rctf{09fa03d6-6d42-4069-90b3-4f43c5febc7c}"

?>