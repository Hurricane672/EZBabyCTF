#!/bin/bash
/game;
