# CheckIn

## How To Setup Environment

mv `challenge.yml` to `.github/workflows/chllenge.yml` in you github repo