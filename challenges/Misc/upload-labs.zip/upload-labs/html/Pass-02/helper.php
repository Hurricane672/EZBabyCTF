<?php

if($_GET['action'] == 'get_prompt'){
    echo '本pass在服务端对数据包的MIME进行检查！';
}

?>