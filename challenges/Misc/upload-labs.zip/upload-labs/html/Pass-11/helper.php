<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass上传路径可控！';
}
?>